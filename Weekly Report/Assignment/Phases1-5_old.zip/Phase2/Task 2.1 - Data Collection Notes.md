# Task 2.1 — Data Collection Report (Working Notes)

Use this file to collect answers before writing the report. Each section maps to a CRISP-DM requirement.

---

## 1. Data Requirements

- What types of data are needed for this project?
- What time period does the data cover?
- What format is the data in?
- What fields are essential vs. optional?

*(Answer here)*

---

## 2. Data Availability

- Were all required fields present in the downloaded dataset?
- Did any expected data turn out to be unavailable?
- How did you verify the data exists and is accessible?

*(Answer here)*

---

## 3. Selection Criteria

- What is the specific data source? (URL, author, platform)
- Why was this dataset chosen over alternatives?
- Which columns from the raw 22-column Kaggle file were kept, and which were dropped? Why?
- What is the difference between the raw file (558 MB) and the resized file (37 MB)?

*(Answer here)*

---

## 4. Tool Compatibility

- What tools did you load the data into? (Python/pandas, Jupyter, etc.)
- Did the CSV load without issues? Any encoding, parsing, or memory problems?
- Version numbers of key libraries used.

*(Answer here)*

---

## 5. Issues / Difficulties Encountered

- Any problems accessing or downloading the data?
- Any surprises in the data structure or content on first load?
- Were there extreme outliers, $0 prices, or missing values visible immediately?
- How were these initial issues handled (or deferred to Phase 3)?

*(Answer here)*

---

## 6. Summary (for the actual report)

*Once the above is filled in, distill into a paragraph or two for the .tex report.*
